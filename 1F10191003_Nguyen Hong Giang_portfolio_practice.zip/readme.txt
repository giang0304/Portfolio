- The index page of my portfolio website is index.html. Meanwhile, the item page that exhibits my INIAD Practice IIB project is practice.html.

- Other than the "Risaiguma" project of INIAD Practice IIB class, I have not added the details for the three other work pages. Therefore, if you click on either of those three projects, you will see a "To be updated" screen. 

